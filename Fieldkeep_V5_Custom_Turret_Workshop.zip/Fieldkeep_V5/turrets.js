/* Fieldkeep V5 — one shared turret ruleset for solo and multiplayer. */
(function(root,factory){const api=factory();if(typeof module==='object'&&module.exports)module.exports=api;if(root)root.FieldkeepTurrets=api;})(typeof globalThis!=='undefined'?globalThis:this,function(){'use strict';
const TYPES={
 pulse:{name:'Sentry Tower',short:'SENTRY',cost:65,color:'#9d8a52',icon:'♜',desc:'Reliable all-round defense',range:134,damage:19,rate:.60,speed:560,targets:'both'},
 interceptor:{name:'Hunter Tower',short:'HUNTER',cost:95,color:'#73867a',icon:'✛',desc:'Long-range heavy shots',range:176,damage:48,rate:1.13,speed:610,targets:'both'},
 cryo:{name:'Net Launcher',short:'NET',cost:110,color:'#6e9dac',icon:'◉',desc:'Slows nearby zombies',range:130,damage:12,rate:1.1,speed:485,targets:'both',slow:.56},
 seismic:{name:'Field Mortar',short:'MORTAR',cost:120,color:'#a76745',icon:'⬟',desc:'Splash damage to crowds',range:140,damage:57,rate:1.4,speed:390,targets:'both',splash:67},
 rapid:{name:'Repeater',short:'RAPID',cost:85,color:'#6e8057',icon:'≋',desc:'Very fast, light shots',range:117,damage:10,rate:.18,speed:630,targets:'both'},
 sniper:{name:'Watchtower',short:'SNIPE',cost:155,color:'#806e55',icon:'⌖',desc:'Huge range and big hits',range:244,damage:118,rate:2.45,speed:1000,targets:'both'},
 venom:{name:'Thorn Thrower',short:'THORN',cost:150,color:'#598a54',icon:'❧',desc:'Poison drains zombie health',range:145,damage:14,rate:.94,speed:490,targets:'both',poison:16},
 storm:{name:'Chain Ballista',short:'CHAIN',cost:205,color:'#8a8861',icon:'⤳',desc:'Jumps to nearby targets',range:165,damage:32,rate:1.25,speed:680,targets:'both',chain:2},
 beacon:{name:'War Drum',short:'BUFF',cost:170,color:'#b18a59',icon:'♫',desc:'Boosts nearby turret damage',range:132,damage:0,rate:0,speed:0,targets:'both',buff:.28},
 harvester:{name:'Supply Cart',short:'COINS',cost:165,color:'#aa874f',icon:'▣',desc:'Earns coins after each wave',range:0,damage:0,rate:0,speed:0,targets:'both',income:34}
};
const EFFECTS=['none','slow','splash','poison','chain'];
const COLORS={none:'#8a8d70',slow:'#659eab',splash:'#b98157',poison:'#638b4c',chain:'#9a865c'};
function onStep(v,min,max,step){return typeof v==='number'&&Number.isFinite(v)&&v>=min&&v<=max&&Math.abs((v-min)/step-Math.round((v-min)/step))<1e-5;}
function normalizeBlueprint(raw){if(!raw||typeof raw!=='object'||Array.isArray(raw))return null;
 const {damage,fireRate,range,speed,effect,power}=raw;
 if(!onStep(damage,10,140,5)||!onStep(fireRate,.5,4.5,.25)||!onStep(range,100,280,10)||!onStep(speed,300,800,50)||!EFFECTS.includes(effect)||!Number.isInteger(power)||power<1||power>3)return null;
 return {damage,fireRate,range,speed,effect,power:effect==='none'?1:power};}
function blueprintCost(raw){const b=normalizeBlueprint(raw);if(!b)return null;
 const multiplier={none:1,slow:1.38,splash:1.82,poison:1.55,chain:2.02}[b.effect];
 const flat={none:0,slow:13,splash:25,poison:16,chain:37}[b.effect];
 const premium=({none:0,slow:14,splash:22,poison:17,chain:27}[b.effect])*(b.power-1);
 const price=30+b.damage*b.fireRate*.78*multiplier+(b.range-100)*.42+(b.speed-300)*.03+flat+premium;
 return Math.round(price/5)*5;}
function customDefinition(raw){const b=normalizeBlueprint(raw);if(!b)return null;
 const d={name:'Custom Turret',short:'CUSTOM',cost:blueprintCost(b),color:COLORS[b.effect],icon:'⚙',desc:'Workshop-designed defense',range:b.range,damage:b.damage,rate:1/b.fireRate,speed:b.speed,targets:'both'};
 if(b.effect==='slow')d.slow=[.67,.49,.34][b.power-1];
 if(b.effect==='splash')d.splash=38+18*b.power;
 if(b.effect==='poison')d.poison=b.damage*(.17+.1*b.power);
 if(b.effect==='chain')d.chain=b.power+1;
 return d;}
function definition(t){if(!t||!t.type)return null;return t.type==='custom'?customDefinition(t.blueprint):TYPES[t.type]||null;}
function stats(t){const d=definition(t);if(!d)return null;const level=Number(t.level)||1;return{range:d.range+(d.range?12*(level-1):0),damage:d.damage*Math.pow(1.37,level-1),rate:d.rate?d.rate*Math.pow(.92,level-1):0,splash:d.splash||0,slow:d.slow||0,poison:d.poison?d.poison*Math.pow(1.25,level-1):0,chain:d.chain||0,buff:d.buff?d.buff+.06*(level-1):0,income:d.income?Math.round(d.income*(1+.65*(level-1))):0};}
function upgradeCost(t){const d=definition(t);return d?Math.round(d.cost*(.65+t.level*.47)):null;}
function sellValue(t){const d=definition(t);return d?Math.round((d.cost+t.spent)*.68):null;}
return{TYPES,EFFECTS,normalizeBlueprint,blueprintCost,customDefinition,definition,stats,upgradeCost,sellValue};
});
