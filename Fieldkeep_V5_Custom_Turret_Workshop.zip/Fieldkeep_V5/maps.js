/* Fieldkeep V4: Shared, deterministic maps for browser and co-op server. */
(function(root, factory){
  const api=factory();
  if(typeof module==='object'&&module.exports)module.exports=api;
  if(root)root.FieldkeepMaps=api;
})(typeof globalThis!=='undefined'?globalThis:this, function(){
  'use strict';
  const CELL=60, COLS=16, ROWS=10;
  const names=[
    ['Willow Meadow','meadow'], ['Pinewood Pass','pine'], ['Riverside Trail','river'],
    ['Golden Farmland','farm'], ['Misty Highlands','moor'], ['Oakheart Grove','forest'],
    ['Wildflower Vale','meadow'], ['Dusty Canyon','desert'], ['Mountain Footpath','stone'],
    ['Lakeside Bend','river'], ['Birchwood Hollow','forest'], ['Mossy Marsh','marsh'],
    ['Autumn Crossing','autumn'], ['Cedar Ridge','pine'], ['Silver Brook','river'],
    ['Sunflower Fields','farm'], ['Rainforest Edge','forest'], ['Frostpine Woods','snow'],
    ['Stonebridge Valley','stone'], ['Prairie Switchbacks','meadow'], ['Whispering Forest','forest'],
    ['Red Clay Mesa','desert'], ['Cloudy Moor','moor'], ['Orchard Road','farm'],
    ['Alpine Meadow','stone'], ['Fernwood Trail','forest'], ['Sandy Outpost','desert'],
    ['Duskwood Valley','autumn'], ['Emerald Basin','meadow'], ['Maple Creek','river'],
    ['Old Fortress Road','stone']
  ];
  const palettes={
    meadow:{grass:'#86b66c',shade:'#5f9d59',light:'#bdd489',soil:'#b69a68',edge:'#658b4b',road:'#d0b486',leaf:'#417d3c',flower:'#f4eabb'},
    pine:{grass:'#789c69',shade:'#426f52',light:'#a7ba7c',soil:'#9b8563',edge:'#4d7653',road:'#baa077',leaf:'#286447',flower:'#e3dbba'},
    river:{grass:'#77b38b',shade:'#439477',light:'#bfcb89',soil:'#a8926a',edge:'#548768',road:'#c9ac80',leaf:'#3c8750',flower:'#f5e2a8'},
    farm:{grass:'#a4bb6e',shade:'#789348',light:'#e0c376',soil:'#b19b6b',edge:'#82964c',road:'#cbb082',leaf:'#538047',flower:'#f6dd74'},
    moor:{grass:'#829687',shade:'#5d8479',light:'#b8bda2',soil:'#9d8a74',edge:'#687f6f',road:'#c0ac91',leaf:'#507466',flower:'#e5dbcf'},
    forest:{grass:'#6c9e61',shade:'#3f7b50',light:'#a7b879',soil:'#988662',edge:'#477750',road:'#bda379',leaf:'#38753f',flower:'#e0d69b'},
    desert:{grass:'#d0b97a',shade:'#bd965c',light:'#ead29a',soil:'#9a7045',edge:'#a18c5f',road:'#e1c793',leaf:'#88925d',flower:'#fff3c6'},
    stone:{grass:'#9fa58a',shade:'#778979',light:'#c4bc9a',soil:'#968573',edge:'#707d6d',road:'#c1ad91',leaf:'#5f7a5a',flower:'#e8dfc0'},
    marsh:{grass:'#728f67',shade:'#547d62',light:'#a1a977',soil:'#907f65',edge:'#5b7861',road:'#b9a276',leaf:'#4a7651',flower:'#dcd6af'},
    autumn:{grass:'#9ca56a',shade:'#718258',light:'#d8b46d',soil:'#9b7959',edge:'#797d51',road:'#c9a67e',leaf:'#b3713b',flower:'#f6d293'},
    snow:{grass:'#d6e3dd',shade:'#b3c8c1',light:'#f1f6e8',soil:'#acaa95',edge:'#b4c7b7',road:'#dad1b6',leaf:'#557f74',flower:'#fbfcf5'}
  };
  function random(seed){let s=seed>>>0;return ()=>((s=(Math.imul(s,1664525)+1013904223)>>>0)/4294967296);}
  function clamp(v,a,b){return Math.max(a,Math.min(b,v));}
  function circleHitsTile(x,y,rad,c,r){const x0=c*CELL,y0=r*CELL,nx=clamp(x,x0,x0+CELL),ny=clamp(y,y0,y0+CELL);return (nx-x)**2+(ny-y)**2<rad*rad;}
  const maps=[];
  for(let day=1;day<=31;day++){
    const [name,biome]=names[day-1],rnd=random(71007+day*29131),theme=palettes[biome];
    // Each map gets its own switchback shape. X always progresses, so paths cannot cross.
    const xs=[-1,2,5,8,11,14,16];
    const row1=2+Math.floor(rnd()*6);let current=row1;
    const gridPath=[[-1,row1],[xs[1],row1]];
    for(let j=1;j<=4;j++){
      let next=1+Math.floor(rnd()*8);
      if(Math.abs(next-current)<2)next=(current+3+j)%8+1;
      gridPath.push([xs[j],next]);
      gridPath.push([xs[j+1],next]);
      current=next;
    }
    const exit=1+Math.floor(rnd()*8);
    if(exit!==current)gridPath.push([14,exit]);
    gridPath.push([16,exit]);
    const points=gridPath.map(([c,r])=>({x:c*CELL+CELL/2,y:r*CELL+CELL/2}));
    const segments=[];let length=0;
    for(let i=1;i<points.length;i++){const a=points[i-1],b=points[i],len=Math.hypot(b.x-a.x,b.y-a.y);if(len>0){segments.push({a,b,start:length,len});length+=len;}}
    const tiles=new Set();
    for(let i=1;i<gridPath.length;i++){
      const [ac,ar]=gridPath[i-1],[bc,br]=gridPath[i],steps=Math.max(Math.abs(bc-ac),Math.abs(br-ar));
      for(let s=0;s<=steps;s++){const c=ac+(bc-ac)*s/steps,r=ar+(br-ar)*s/steps;
        if(c>=0&&c<COLS&&r>=0&&r<ROWS)tiles.add(`${c},${r}`);
      }
    }
    // Natural obstacles never cover the road. Trees have wider canopy hitboxes.
    const trees=[],rocks=[],ponds=[];
    function touchesPath(x,y,rad){for(let r=0;r<ROWS;r++)for(let c=0;c<COLS;c++)if(tiles.has(`${c},${r}`)&&circleHitsTile(x,y,rad,c,r))return true;return false;}
    function freeSpot(x,y,rad){if(x-rad<7||x+rad>953||y-rad<8||y+rad>590||touchesPath(x,y,rad+7))return false;
      return !trees.some(t=>Math.hypot(t.x-x,t.y-y-18*t.k)<rad+27*t.k+12)&&
        !rocks.some(p=>Math.hypot(p.x-x,p.y-y)<rad+24)&&
        !ponds.some(p=>Math.hypot(p.x-x,p.y-y)<rad+p.r+10);
    }
    const waterBiomes=['river','marsh'];
    const pondCount=waterBiomes.includes(biome)?2:(day===9||day===29?1:0);
    for(let i=0,tries=0;i<pondCount&&tries<400;tries++){
      const x=50+rnd()*850,y=50+rnd()*490,r=22+rnd()*15;
      if(freeSpot(x,y,r+5)){ponds.push({x,y,r});i++;}
    }
    const desiredTrees=(biome==='desert'?5:biome==='farm'?9:biome==='snow'?12:biome==='forest'||biome==='pine'?19:13)+(day%4);
    for(let tries=0;trees.length<desiredTrees&&tries<1200;tries++){
      const x=42+rnd()*870,y=56+rnd()*480,k=.7+rnd()*.35;
      if(freeSpot(x,y-14*k,27*k))trees.push({x,y,k});
    }
    const desiredRocks=biome==='stone'||biome==='desert'?10:5;
    for(let tries=0;rocks.length<desiredRocks&&tries<600;tries++){
      const x=24+rnd()*912,y=22+rnd()*554;
      if(freeSpot(x,y,16))rocks.push({x,y});
    }
    function invalidTile(c,r){
      if(!Number.isInteger(c)||!Number.isInteger(r)||c<0||c>=COLS||r<0||r>=ROWS)return 'Outside the battlefield';
      if(tiles.has(`${c},${r}`))return 'You cannot build on the dirt road';
      if(trees.some(t=>circleHitsTile(t.x,t.y-18*t.k,30*t.k,c,r)||circleHitsTile(t.x,t.y+7*t.k,9*t.k,c,r)))return 'You cannot build on a tree';
      if(rocks.some(p=>circleHitsTile(p.x,p.y,17,c,r)))return 'You cannot build on a rock';
      if(ponds.some(p=>circleHitsTile(p.x,p.y,p.r+4,c,r)))return 'You cannot build on water';
      return null;
    }
    const blocked=[];for(let r=0;r<ROWS;r++)for(let c=0;c<COLS;c++){const why=invalidTile(c,r);if(why)blocked.push({c,r,why});}
    function positionAt(dist){for(const s of segments)if(dist<=s.start+s.len){const t=clamp((dist-s.start)/s.len,0,1);return{x:s.a.x+(s.b.x-s.a.x)*t,y:s.a.y+(s.b.y-s.a.y)*t};}return{...points[points.length-1]};}
    maps.push({day,name,biome,theme,gridPath,points,segments,pathLength:length,pathTiles:tiles,trees,rocks,ponds,blocked,invalidTile,positionAt,seed:day*1213+26713});
  }
  function getMap(day){const n=Number(day);return maps[Number.isInteger(n)&&n>=1&&n<=31?n-1:0];}
  return {getMap,days:maps.map(({day,name,biome})=>({day,name,biome})),CELL,COLS,ROWS};
});
