'use strict';
// Fieldkeep V5 cooperative zombie defense server (no npm dependencies).
// Server-authoritative simulation and shared rooms over HTTP + Server-Sent Events.
const http = require('node:http');
const fs = require('node:fs');
const path = require('node:path');
const crypto = require('node:crypto');
const os = require('node:os');

const PORT = Number(process.env.PORT) || 3000;
const {getMap, CELL, COLS, ROWS} = require('./maps.js');
const Turrets=require('./turrets.js');
const TYPES=Turrets.TYPES;
const MAX_PLAYERS=5, MAX_ROOMS=100;
function newGame(){return{towers:[],enemies:[],shots:[],credits:320,health:20,wave:0,kills:0,active:false,paused:false,speed:1,gameOver:false,spawnQueue:[],spawnTime:0,spawnInterval:.7,spawnedCount:0,totalSpawned:0,clock:0,bestWave:0,uid:1};}
const rooms=new Map(), sessions=new Map();
const alphabet='ABCDEFGHJKLMNPQRSTUVWXYZ23456789';
function roomCode(){let code;do{code='';for(let i=0;i<6;i++)code+=alphabet[crypto.randomInt(alphabet.length)];}while(rooms.has(code));return code;}
function token(){return crypto.randomBytes(24).toString('hex');}
function cleanName(raw){return String(raw||'').replace(/[^\p{L}\p{N} ._\-]/gu,'').trim().slice(0,18)||'Ranger';}
function createPlayer(room,name){const player={id:crypto.randomBytes(7).toString('hex'),name:cleanName(name),token:token(),clients:new Set(),lastSeen:Date.now()};room.players.set(player.id,player);sessions.set(player.token,{room,player});return player;}
function publicRoom(room,player){const g=room.game;return{code:room.code,youId:player.id,hostId:room.hostId,mapDay:room.map.day,mapName:room.map.name,players:[...room.players.values()].map(p=>({id:p.id,name:p.name,connected:p.clients.size>0})),blocked:room.map.blocked,game:{
 credits:g.credits,health:g.health,wave:g.wave,kills:g.kills,active:g.active,paused:g.paused,speed:g.speed,gameOver:g.gameOver,spawnedCount:g.spawnedCount,totalSpawned:g.totalSpawned,bestWave:g.bestWave,clock:g.clock,
 towers:g.towers.map(t=>({id:t.id,c:t.c,r:t.r,x:t.x,y:t.y,type:t.type,blueprint:t.blueprint||null,level:t.level,spent:t.spent,angle:t.angle})),
 enemies:g.enemies.map(e=>({id:e.id,type:e.type,x:e.x,y:e.y,d:e.d,maxHp:e.maxHp,hp:e.hp,air:e.air,color:e.color,r:e.r,slowT:e.slowT,poisonT:e.poisonT||0})),
 shots:g.shots.map(s=>({x:s.x,y:s.y,color:s.color,r:s.r}))
 }};}
function sseWrite(res,event,data){try{res.write(`event: ${event}\ndata: ${JSON.stringify(data)}\n\n`);}catch{}}
function broadcast(room){for(const player of room.players.values()){if(!player.clients.size)continue;const state=publicRoom(room,player);for(const res of player.clients)sseWrite(res,'state',state);}}
function announce(room,msg){for(const p of room.players.values())for(const res of p.clients)sseWrite(res,'notice',{message:msg});}
const tStats=Turrets.stats;
const upgradeCost=Turrets.upgradeCost;
const sellValue=Turrets.sellValue;
function startWave(g){if(g.active||g.gameOver)return 'The wave has already started';g.wave++;g.bestWave=Math.max(g.bestWave,g.wave);g.spawnQueue=[];
 const n=8+Math.floor(g.wave*2.6);for(let i=0;i<n;i++){let type;if(g.wave>=7&&i%4===0)type='crawler';else if(g.wave>=4&&i%9===0)type='warden';else if(g.wave>=3&&i%5===0)type='dart';else type='glider';g.spawnQueue.push(type);}
 if(g.wave%5===0)g.spawnQueue.push('boss');g.totalSpawned=g.spawnQueue.length;g.spawnedCount=0;g.spawnTime=0;g.spawnInterval=Math.max(.27,.71-g.wave*.013);g.active=true;return null;}
function spawn(g,type,map){let hp,vel,reward,color,r,air=false;const scale=Math.pow(1.13,g.wave-1);switch(type){
 case'dart':hp=26*scale;vel=124+g.wave*.5;reward=8;color='#b6c86b';r=12;break;
 case'warden':hp=125*scale;vel=52+g.wave*.25;reward=17;color='#759b68';r=20;break;
 case'crawler':hp=70*scale;vel=72+g.wave*.4;reward=12;color='#9baa72';r=15;break;
 case'boss':hp=500*scale;vel=40+g.wave*.2;reward=110;color='#7eaf70';r=28;break;
 default:hp=46*scale;vel=80+g.wave*.45;reward=9;color='#9fc083';r=14;}
 const p=map.positionAt(0);g.enemies.push({id:g.uid++,type,x:p.x,y:p.y,d:0,maxHp:hp,hp,speed:vel,air,reward,color,r,slowT:0,slowFactor:1,poisonT:0,poisonDps:0});}
function hit(g,e,damage){if(e.hp<=0)return;const multiplier=e.type==='warden'?.74:1;e.hp-=damage*multiplier;if(e.hp<=0){g.enemies=g.enemies.filter(v=>v!==e);g.credits+=e.reward;g.kills++;}}
function targeting(g,t){const s=tStats(t),def=Turrets.definition(t);if(!s||!s.rate)return null;let best=null;for(const e of g.enemies){if(Math.hypot(t.x-e.x,t.y-e.y)>s.range)continue;if(!best||e.d>best.d)best=e;}return best;}
function boost(g,t){let b=1;for(const x of g.towers)if(x!==t&&x.type==='beacon'&&Math.hypot(x.x-t.x,x.y-t.y)<=tStats(x).range)b=Math.max(b,1+tStats(x).buff);return b;}
function waveIncome(g){let n=40+g.wave*3;for(const t of g.towers)n+=tStats(t).income;return n;}
function impact(g,s,target){
 const nearby=()=>[...g.enemies].filter(e=>Math.hypot(e.x-target.x,e.y-target.y)<=95&&e!==target).sort((a,b)=>a.d-b.d);
 if(s.splash){for(const e of [...g.enemies])if(Math.hypot(e.x-target.x,e.y-target.y)<=s.splash)hit(g,e,s.damage);return;}
 if(s.slow){target.slowT=1.6;target.slowFactor=s.slow;}
 if(s.poison){target.poisonT=3.2;target.poisonDps=Math.max(target.poisonDps||0,s.poison);}
 hit(g,target,s.damage);
 if(s.chain){for(const e of nearby().slice(0,s.chain))hit(g,e,s.damage*.56);}
}
function update(g,dt,map){g.clock+=dt;if(g.gameOver)return;
 if(g.active){g.spawnTime-=dt;while(g.spawnQueue.length&&g.spawnTime<=0){spawn(g,g.spawnQueue.shift(),map);g.spawnedCount++;g.spawnTime+=g.spawnInterval;}}
 for(let i=g.enemies.length-1;i>=0;i--){const e=g.enemies[i];e.slowT=Math.max(0,e.slowT-dt);
  if(e.poisonT>0){e.poisonT=Math.max(0,e.poisonT-dt);hit(g,e,(e.poisonDps||0)*dt);if(e.poisonT===0)e.poisonDps=0;if(!g.enemies.includes(e))continue;}
  e.d+=e.speed*(e.slowT>0?e.slowFactor:1)*dt;const p=map.positionAt(e.d);e.x=p.x;e.y=p.y;
  if(e.d>=map.pathLength){g.enemies.splice(g.enemies.indexOf(e),1);g.health=Math.max(0,g.health-(e.type==='boss'?4:1));if(g.health<=0){g.gameOver=true;g.active=false;break;}}}
 if(g.gameOver)return;
 for(const t of g.towers){const def=Turrets.definition(t),st=tStats(t);if(!st.rate)continue;t.cool-=dt;if(t.cool>0)continue;const target=targeting(g,t);if(!target)continue;
 t.angle=Math.atan2(target.y-t.y,target.x-t.x);t.cool=st.rate;
 g.shots.push({x:t.x,y:t.y,targetId:target.id,damage:st.damage*boost(g,t),speed:def.speed,color:def.color,r:st.splash?7:4,splash:st.splash,slow:st.slow,poison:st.poison,chain:st.chain,life:2.5});}
 for(let i=g.shots.length-1;i>=0;i--){const s=g.shots[i];s.life-=dt;if(s.life<=0){g.shots.splice(i,1);continue;}const target=g.enemies.find(e=>e.id===s.targetId);if(!target){g.shots.splice(i,1);continue;}
  const dx=target.x-s.x,dy=target.y-s.y,dist=Math.hypot(dx,dy),move=s.speed*dt;
  if(dist<=move+5){impact(g,s,target);g.shots.splice(i,1);}else{s.x+=(dx/dist)*move;s.y+=(dy/dist)*move;}}
 if(g.active&&!g.spawnQueue.length&&!g.enemies.length){g.active=false;g.credits+=waveIncome(g);}
}
function applyAction(room,player,action,payload){const g=room.game,host=room.hostId===player.id;
 switch(action){
 case 'build':{const {c,r,type}=payload||{};if(g.gameOver)return 'Restart the game first';const blueprint=type==='custom'?Turrets.normalizeBlueprint(payload?.blueprint):null;if(type==='custom'&&!blueprint)return 'Invalid custom turret design';const d=type==='custom'?Turrets.customDefinition(blueprint):(typeof type==='string'&&Object.hasOwn(TYPES,type)?TYPES[type]:null);if(!d)return 'Unknown turret';const invalid=room.map.invalidTile(c,r);if(invalid)return invalid;if(g.towers.some(t=>t.c===c&&t.r===r))return 'That tile already has a turret';if(g.credits<d.cost)return 'The team needs more coins';g.credits-=d.cost;g.towers.push({id:g.uid++,c,r,x:c*CELL+CELL/2,y:r*CELL+CELL/2,type,blueprint,level:1,spent:0,cool:Math.random()*.25,angle:-Math.PI/2});return null;}
 case 'upgrade':{const t=g.towers.find(t=>t.id===payload?.id);if(!t)return 'Turret no longer exists';if(g.gameOver)return 'Game over';if(t.level>=5)return 'Already max level';const cost=upgradeCost(t);if(g.credits<cost)return 'The team needs more coins';g.credits-=cost;t.spent+=cost;t.level++;return null;}
 case 'sell':{const t=g.towers.find(t=>t.id===payload?.id);if(!t)return 'Turret no longer exists';if(g.gameOver)return 'Game over';g.credits+=sellValue(t);g.towers=g.towers.filter(x=>x!==t);return null;}
 case 'startWave':if(!host)return 'Only the room host can start waves';if(g.paused)return 'Resume before starting a wave';return startWave(g);
 case 'pause':if(!host)return 'Only the room host can pause';if(g.gameOver)return 'Game over';g.paused=!g.paused;return null;
 case 'speed':if(!host)return 'Only the room host can change speed';g.speed=g.speed===1?2:1;return null;
 case 'reset':if(!host)return 'Only the room host can restart';room.game=newGame();return null;
 case 'setMap':{
  if(!host)return 'Only the room host can change maps';
  const day=payload?.day;
  if(!Number.isInteger(day)||day<1||day>31)return 'Choose a map between 1 and 31';
  if(room.map.day!==day){room.map=getMap(day);room.game=newGame();announce(room,`Map changed to Day ${day}: ${room.map.name}. Fresh game started!`);}
  return null;
 }
 default:return 'Unknown action';
 }
}
function json(res,status,data){res.writeHead(status,{'Content-Type':'application/json; charset=utf-8','Cache-Control':'no-store','X-Content-Type-Options':'nosniff'});res.end(JSON.stringify(data));}
async function readJson(req){return new Promise((resolve,reject)=>{let body='',length=0;req.on('data',chunk=>{length+=chunk.length;if(length>8192){reject(new Error('Request too large'));req.destroy();return;}body+=chunk;});req.on('end',()=>{try{resolve(JSON.parse(body||'{}'));}catch{reject(new Error('Invalid JSON'));}});req.on('error',reject);});}
function endPlayer(room,player){for(const res of player.clients){try{res.end();}catch{}}player.clients.clear();room.players.delete(player.id);sessions.delete(player.token);if(room.hostId===player.id)room.hostId=room.players.keys().next().value||null;
 if(!room.players.size){rooms.delete(room.code);}else{announce(room,`${player.name} left the team`);broadcast(room);}}
function clientIpHint(){const ips=[];for(const net of Object.values(os.networkInterfaces()))for(const row of net||[]){if(row.family==='IPv4'&&!row.internal)ips.push(row.address);}return [...new Set(ips)];}
const indexFile=fs.readFileSync(path.join(__dirname,'public','index.html'));
const server=http.createServer(async(req,res)=>{
 const url=new URL(req.url,'http://localhost');
 if(req.method==='GET'&&(url.pathname==='/'||url.pathname==='/index.html')){res.writeHead(200,{'Content-Type':'text/html; charset=utf-8','Cache-Control':'no-store','X-Content-Type-Options':'nosniff'});res.end(indexFile);return;}
 if(req.method==='GET'&&url.pathname==='/api/health'){json(res,200,{ok:true,playersPerRoom:MAX_PLAYERS,lanUrls:/^(localhost|127\.0\.0\.1)(:|$)/.test(req.headers.host||'')?clientIpHint().map(ip=>`http://${ip}:${PORT}`):[]});return;}
 if(req.method==='GET'&&url.pathname==='/api/me'){const ses=sessions.get(url.searchParams.get('token'));if(!ses){json(res,401,{error:'Session expired'});return;}json(res,200,{ok:true,code:ses.room.code,playerId:ses.player.id,hostId:ses.room.hostId});return;}
 if(req.method==='GET'&&url.pathname==='/api/events'){
  const ses=sessions.get(url.searchParams.get('token'));if(!ses){json(res,401,{error:'Room not found'});return;}
  const {room,player}=ses;player.lastSeen=Date.now();res.writeHead(200,{'Content-Type':'text/event-stream; charset=utf-8','Cache-Control':'no-cache, no-transform','Connection':'keep-alive','X-Accel-Buffering':'no','X-Content-Type-Options':'nosniff'});res.write(': connected\n\n');player.clients.add(res);sseWrite(res,'state',publicRoom(room,player));broadcast(room);
  res.on('close',()=>{player.clients.delete(res);player.lastSeen=Date.now();broadcast(room);});return;
 }
 if(req.method==='POST'&&url.pathname.startsWith('/api/')){
  // Same-origin commands; no cross-site room control.
  const origin=req.headers.origin;if(origin){let allowed=false;try{allowed=new URL(origin).host===req.headers.host;}catch{}if(!allowed){json(res,403,{error:'Invalid origin'});return;}}
  let data;try{data=await readJson(req);}catch(e){json(res,400,{error:e.message});return;}
  if(url.pathname==='/api/create'){
   if(rooms.size>=MAX_ROOMS){json(res,503,{error:'Server room limit reached'});return;}const code=roomCode(),room={code,players:new Map(),hostId:null,map:getMap(data.day||new Date().getDate()),game:newGame(),lastActivity:Date.now()};rooms.set(code,room);const player=createPlayer(room,data.name);room.hostId=player.id;json(res,200,{ok:true,code,token:player.token,playerId:player.id,hostId:room.hostId});return;}
  if(url.pathname==='/api/join'){
   const code=String(data.code||'').trim().toUpperCase(),room=rooms.get(code);if(!room){json(res,404,{error:'Room code not found'});return;}if(room.players.size>=MAX_PLAYERS){json(res,409,{error:'This room is full (5 players)'});return;}const player=createPlayer(room,data.name);room.lastActivity=Date.now();json(res,200,{ok:true,code,token:player.token,playerId:player.id,hostId:room.hostId});announce(room,`${player.name} joined the defense`);broadcast(room);return;}
  const ses=sessions.get(data.token);if(!ses){json(res,401,{error:'Session expired — join again'});return;}const {room,player}=ses;
  if(url.pathname==='/api/leave'){json(res,200,{ok:true});endPlayer(room,player);return;}
  if(url.pathname==='/api/action'){
   if(typeof data.action!=='string'){json(res,400,{error:'Missing action'});return;}
   const err=applyAction(room,player,data.action,data.payload);if(err){json(res,400,{error:err});return;}
   room.lastActivity=Date.now();json(res,200,{ok:true});broadcast(room);return;
  }
 }
 json(res,404,{error:'Not found'});
});
server.listen(PORT,'0.0.0.0',()=>{
 console.log('\n🌳 FIELDKEEP V5 — TURRET WORKSHOP CO-OP SERVER');
 console.log(`Your game:  http://localhost:${PORT}`);
 for(const ip of clientIpHint())console.log(`Same Wi-Fi: http://${ip}:${PORT}`);
 console.log('Rooms support up to 5 players. Press Ctrl+C to stop.\n');
});
let last=Date.now(),elapsed=0;
setInterval(()=>{
 const now=Date.now(),dt=Math.min(.08,(now-last)/1000);last=now;elapsed+=dt;
 for(const room of rooms.values()){
  if(![...room.players.values()].some(p=>p.clients.size>0))continue;
  const g=room.game;if(!g.paused&&!g.gameOver){const before=g.active,health=g.health;update(g,dt*g.speed,room.map);if(before&&!g.active&&g.health>0)announce(room,`Wave ${g.wave} cleared! Bonus coins earned`);if(health>0&&g.gameOver)announce(room,'The gate has fallen!');}
 }
 if(elapsed>=.12){elapsed=0;for(const room of rooms.values())if([...room.players.values()].some(p=>p.clients.size>0))broadcast(room);}
},33).unref();
setInterval(()=>{
 const now=Date.now();for(const room of [...rooms.values()]){
  for(const p of [...room.players.values()])if(p.clients.size===0&&now-p.lastSeen>3*60_000)endPlayer(room,p);
  if(room.players.size===0||(![...room.players.values()].some(p=>p.clients.size>0)&&now-room.lastActivity>30*60_000)){
   for(const p of [...room.players.values()])sessions.delete(p.token);rooms.delete(room.code);
  }
 }
},60_000).unref();
