@echo off
cd /d "%~dp0"
where node >nul 2>&1
if errorlevel 1 (
  echo Node.js is required. Install the LTS version from https://nodejs.org/
  pause
  exit /b 1
)
echo Starting the Fieldkeep co-op game server in a separate window...
start "FIELDKEEP SERVER" /D "%~dp0" cmd /k node server.js
timeout /t 2 /nobreak >nul
start "" "http://localhost:3000"
echo The browser game is opening now.
echo Keep the FIELDKEEP SERVER window open while playing with friends.
