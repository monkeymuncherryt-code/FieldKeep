FIELDKEEP V5 — EARTH DEFENSE / TURRET WORKSHOP
================================================

PLAY SOLO — NO SETUP
1. Open PLAY_SOLO.html in Chrome, Edge, or Opera GX.
2. Choose one of the 31 maps (the day of the month is selected automatically).
3. Use the shop to place a turret on empty grass. No building on roads, trees, rocks, or water.
4. Press Start Wave. Protect your gate's 20 hearts.

CUSTOM TURRET WORKSHOP
- Adjust damage, shots per second, range, and projectile travel speed.
- Choose a special ability: slow, splash, poison, chain, or none; increase its level (1–3).
- Watch the coin price and damage-per-second estimate update in real time.
- Choose save slot 1–4 and click Save & Equip.
- The custom turret appears in the shop; click grass to place it when you can afford it.
- Your FOUR blueprint slots are saved to your browser's local storage.
- In multiplayer, each player may bring their own local blueprints; purchased turrets are synchronized.
- Changing a saved slot will not alter turrets already built on the map.
- The server validates all custom stats and computes the price; the browser cannot set its own cost.

TOWER TYPES
Sentry (65) — reliable; Hunter (95) — long range; Net (110) — slow;
Mortar (120) — splash; Repeater (85) — rapid fire; Watchtower (155) — high damage;
Thorn Thrower (150) — poison damage over time; Chain Ballista (205) — hits extra enemies;
War Drum (170) — damage boost aura; Supply Cart (165) — extra coins on cleared waves.
All turrets may be upgraded 4 times (levels 1–5).
War Drum buffs do not stack; strongest nearby buff applies.

PLAY WITH UP TO 5 PLAYERS ON ONE NETWORK
1. Install Node.js 18 or newer from its official website, if you don't already have it.
2. Double-click START_FIELDKEEP.bat or run `node server.js` from this folder.
3. The host opens http://localhost:3000 and clicks Create Room.
4. Other players connect to the host's printed Wi-Fi address, enter the 6-character code, and join.
5. All players share coins, turrets, waves and gate health. Only the host starts/pauses waves
   and changes maps. Switching to a new map restarts the room's current match.
6. Room codes are valid only on the SAME server. Internet play from different houses
   requires safely hosting the server online; room codes alone are not internet hosting.

Controls: keys 1–9 for first nine preset towers; 0 for Supply Cart;
Space starts a wave; P pauses; Esc clears selection. Click a placed turret for upgrade/sell.

Notes: Multiplayer progress lives in server memory until room/server restart.
All solo progress beyond the saved blueprint slots and best wave is reset when the page reloads.
No dependencies or accounts required for solo mode. Game is an original fan-made prototype.
